
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 9584013
 */
public class Exemplo {
    
    private List<Sala> salas = new ArrayList<Sala>();
    private List<Gerente> gerentes = new ArrayList<Gerente>();
    
    public void run() {
        insereSalas();
        insereGerentes();
        mostraRegistros();
    }
    
    public void insereSalas() {
        Sala sala1 = new Sala(101, "Alpha", 1);
        Sala sala2 = new Sala(102, "Alpha", 1);
        Sala sala3 = new Sala(205, "Alpha", 2);
        Sala sala4 = new Sala(346, "Beta", 5);
        Sala sala5 = new Sala(12, "Gamma", 3);
        
        salas.add(sala1);
        salas.add(sala2);
        salas.add(sala3);
        salas.add(sala4);
        salas.add(sala5);
    }
    
    public void insereGerentes() {
        Gerente gerente1 = new Gerente(123456, "José da Silva", "Compras");
        Gerente gerente2 = new Gerente(654321, "Maria Pereira", "Vendas");
        Gerente gerente3 = new Gerente(123789, "João Assunção", "Marketing");
        Gerente gerente4 = new Gerente(987321, "Ana Maria Rodrigues", "Produção");
        
        gerente1.setSala(salas.get(0));
        gerente2.setSala(salas.get(1));
        gerente3.setSala(salas.get(2));
        gerente4.setSala(salas.get(0));
        
        gerentes.add(gerente1);
        gerentes.add(gerente2);
        gerentes.add(gerente3);
        gerentes.add(gerente4);
    }
    
    public void mostraRegistros() {
        
        for(Gerente g : gerentes) {
            if(g.getSala() != null)
                System.out.println(g.getNome() + " trabalha na sala " + g.getSala().getNumero() + " do prédio " + g.getSala().getPredio() + ".");
            else
                System.out.println(g.getNome() + " não possui uma sala de trabalho.");
        }
        
        System.out.println("");
        
        for(Sala s : salas) {
            if(s.getGerente() != null)
                System.out.println("Na sala " + s.getNumero() + " do prédio " + s.getPredio() + " trabalha " + s.getGerente().getNome() + ".");
            else
                System.out.println("Na sala " + s.getNumero() + " do prédio " + s.getPredio() + " não trabalha nenhum gerente.");
        }
    }

    public List<Sala> getSalas() {
        return salas;
    }

    public void setSalas(List<Sala> salas) {
        this.salas = salas;
    }

    public List<Gerente> getGerentes() {
        return gerentes;
    }

    public void setGerentes(List<Gerente> gerentes) {
        this.gerentes = gerentes;
    }
}
