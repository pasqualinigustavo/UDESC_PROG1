/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 9584013
 */
public class Gerente {
    private int matricula;
    private String nome;
    private String funcao;
    private Sala sala;

    public Gerente() {}

    public Gerente(int matricula, String nome, String funcao) {
        this.matricula = matricula;
        this.nome = nome;
        this.funcao = funcao;
    }
    
    public Gerente(int matricula, String nome, String funcao, Sala sala) {
        this.matricula = matricula;
        this.nome = nome;
        this.funcao = funcao;
        setSala(sala);
    }

    public Sala getSala() {
        return sala;
    }

    public void setSala(Sala sala) {
        this.sala = sala;
        
        if(sala != null)
            sala.setGerente(this);
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }
}
