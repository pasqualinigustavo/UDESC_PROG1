/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 9584013
 */
public class Sala {
    private int numero;
    private String predio;
    private int andar;
    private Gerente gerente;

    public Sala() {}

    public Sala(int numero, String predio, int andar) {
        this.numero = numero;
        this.predio = predio;
        this.andar = andar;
    }

    public Gerente getGerente() {
        return gerente;
    }

    public void setGerente(Gerente gerente) {
        if(this.gerente != null)
            this.gerente.setSala(null);
        
        this.gerente = gerente;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getPredio() {
        return predio;
    }

    public void setPredio(String predio) {
        this.predio = predio;
    }

    public int getAndar() {
        return andar;
    }

    public void setAndar(int andar) {
        this.andar = andar;
    }
}
