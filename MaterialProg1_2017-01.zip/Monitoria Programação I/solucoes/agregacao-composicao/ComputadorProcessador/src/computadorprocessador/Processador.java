/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computadorprocessador;

/**
 *
 * @author marcelo
 */
public class Processador {
    private int nucleos;
    private double potencia;

    public int getNucleos() {
            return nucleos;
    }

    public void setNucleos(int nucleos) {
            this.nucleos = nucleos;
    }

    public double getPotencia() {
            return potencia;
    }

    public void setPotencia(double potencia) {
            this.potencia = potencia;
    }
}
