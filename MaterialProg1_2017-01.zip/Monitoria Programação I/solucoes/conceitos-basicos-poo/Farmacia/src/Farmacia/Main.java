package Farmacia;

public class Main {
    
    public static void main(String[] args) {
        Principal p = new Principal();
        p.run();
    }    
}
